#!/bin/bash
$( dirname "${BASH_SOURCE[0]}" )/SudokuSolverConsole --listen
